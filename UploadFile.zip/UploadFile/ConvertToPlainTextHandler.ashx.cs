﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace UploadFile
{
    /// <summary>
    /// Summary description for ConvertToPlainTextHandler
    /// </summary>
    public class ConvertToPlainTextHandler : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            //Lấy đường dẫn tệp từ tham số truy vấn
            string filePath = context.Request.QueryString["path"];
           // context.Response.Write("Không phải file ảnh");
            if (!string.IsNullOrEmpty(filePath))
            {
                try
                {
                    // Đọc nội dung của tệp
                    if (File.Exists(context.Server.MapPath("~/uploads/" + filePath)))
                    {
                        string fileContent = File.ReadAllText(context.Server.MapPath("~/uploads/" + filePath));

                        // Thiết lập Header để trình duyệt hiểu rằng đây là văn bản thuần
                        context.Response.ContentType = "text/plain";

                        // Gửi nội dung đã chuyển đổi về trình duyệt
                        context.Response.Write(fileContent);
                    }else
                    {
                        context.Response.StatusCode = 400;
                        context.Response.Write("Không tồn tại files");
                    }    
                }
                catch (Exception ex)
                {
                    // Xử lý lỗi nếu cần
                    context.Response.StatusCode = 500;
                    context.Response.Write("Lỗi khi xử lý tệp: " + ex.Message);
                }
            }
            else
            {
                // Trả về mã trạng thái 400 nếu không có đường dẫn tệp được cung cấp
                context.Response.StatusCode = 400;
                context.Response.Write("Thiếu đường dẫn tệp.");
            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}