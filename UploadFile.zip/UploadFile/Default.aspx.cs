﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
//using System.Web.UI.WebControls;
using System.IO;
namespace UploadFile
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        // white list ref
        //https://www.thoughtco.com/mime-types-by-content-type-3469108
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void btnUpload_Click(object sender, EventArgs e)
        {
            // Kiểm tra xem người dùng đã chọn tệp chưa
            if (fileUpload.HasFile)
            {
                try
                {
                    // Lấy thông tin về tệp
                    string fileName = Path.GetFileName(fileUpload.FileName);
                    string fileExtension = Path.GetExtension(fileName).ToLower();
                    string[] whitelist = { ".jpg", ".jpeg", ".png", ".gif", ".bmp", ".tif", ".pdf", ".docx", ".doc", ".xls", ".xlsx" };
                    if(whitelist.Contains(fileExtension)==false)
                    {
                        lblMessage.Text = "Chỉ cho phép tải lên các tệp hình ảnh (jpg, jpeg, png, gif).";
                        return;
                    }
                    string whitemimeType = "image/apng|image/avif|mage/gif|image/jpeg|image/png|image/bmp|image/svg+xml|image/webp";
                    string[] whitemimeTypes = whitemimeType.Split('|');
                    string mimeType = MimeMapping.GetMimeMapping(fileName);
                    if(whitemimeTypes.Contains(mimeType)==false)
                    {
                        lblMessage.Text = "Chỉ cho phép tải lên các tệp hình ảnh (jpg, jpeg, png, gif).";
                        return;
                    }
                   // Label1.Text = "Mine Type: " + mimeType;
                        // Đường dẫn lưu trữ tệp tải lên
                        string filePath = Server.MapPath("~/Uploads/") + fileName;

                    // Kiểm tra kích thước tệp (giả sử giới hạn là 10MB)
                    if (fileUpload.PostedFile.ContentLength <= 10485760)
                    {
                        // Lưu tệp vào thư mục Uploads
                        fileUpload.SaveAs(filePath);

                        // Hiển thị thông báo thành công
                        lblMessage.Text = "Tệp đã được tải lên thành công. ";
                        HyperLink1.NavigateUrl = "~/Uploads/" + fileName;
                        HyperLink1.Text = "/Uploads/" + fileName;
                        HyperLink1.Visible = true;
                    }
                    else
                    {
                        // Hiển thị thông báo lỗi về kích thước tệp
                        lblMessage.Text = "Kích thước của tệp vượt quá giới hạn cho phép (10MB).";
                    }
                }
                catch (Exception ex)
                {
                    // Hiển thị thông báo lỗi chung (có thể thêm xử lý cụ thể cho từng loại lỗi)
                    lblMessage.Text = "Lỗi: " + ex.Message;
                }
            }
            else
            {
                // Hiển thị thông báo nếu không có tệp nào được chọn
                lblMessage.Text = "Vui lòng chọn một tệp để tải lên.";
            }
        }

    }
}